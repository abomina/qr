'use strict';

const modules = [
  'webcam',
  'bcQrReader'
];

var demoApp = angular.module('demoApp', modules);
